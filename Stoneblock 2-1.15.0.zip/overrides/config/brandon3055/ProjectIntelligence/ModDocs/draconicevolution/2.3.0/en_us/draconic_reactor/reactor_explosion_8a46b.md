§align:center
##### §nThis is the worst that can happen.§n

§img[http://ss.brandon3055.com/a44a2]{width:100%}
§rule{colour:0x606060,height:3,width:100%}
It may be hard to tell just how big that crator is so §link[http://ss.brandon3055.com/808c9]{alt_text:"Heres a larger image and a village for scale"}.

This is what happens when a max size reactor detonates. Smaller reactors are less destructive but any size reactor will still make a sizable dent in your world.

§link[http://ss.brandon3055.com/03228]{alt_text:"Heres a close up of the crator."}
§rule{colour:0x606060,height:3,width:100%}