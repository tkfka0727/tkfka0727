§align:center
##### §nEnergy Infuser§n

§stack[draconicevolution:energy_infuser]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Seeing the need for faster energy transfer you have found a way to bring the Infuser to being.

This charger is capable of charging items at up to 1 million RF/t.
But it should be noted the actual charge rate is limited by the max intake rate of the item being charged.
This charger is ideal for charging Draconic Evolution items as they are capable of accepting energy at an extremely fast rate.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_infuser]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}