§align:center
##### §nWyvern Chestplate§n

§stack[draconicevolution:wyvern_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+80 Base Shield Capacity
+2 Armor Toughness
+8 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_chest]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}