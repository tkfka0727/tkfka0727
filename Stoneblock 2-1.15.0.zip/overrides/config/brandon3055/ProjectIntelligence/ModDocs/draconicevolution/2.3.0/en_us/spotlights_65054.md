§align:center
###### §nSpotlights by direwolf20§n
§table{width:100%,render_cells:false} 
<table column_layout="1*,1*">
<tr align="center" padding="0,4,0,4">
	<td>
		§img[http://ss.brandon3055.com/759a8]{link_to:"https://www.youtube.com/watch?v=iBcRT4C6RkQ",width:100%}
		§link[https://www.youtube.com/watch?v=iBcRT4C6RkQ]
	</td>
	<td>
		§img[http://ss.brandon3055.com/82f58]{link_to:"https://www.youtube.com/watch?v=2RRddsks9TA",width:100%}
		§link[https://www.youtube.com/watch?v=2RRddsks9TA]
	</td>
</tr>
</table>

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

###### §nSpotlights by The MindCrafters§n
§table{width:100%,render_cells:false} 
<table column_layout="1*,1*">
<tr align="center" padding="0,4,0,4">
	<td>
		§img[http://ss.brandon3055.com/94b75]{link_to:"https://www.youtube.com/watch?v=AIO3hSGceC0",width:100%}
		§link[https://www.youtube.com/watch?v=AIO3hSGceC0]
	</td>
	<td>
		§img[http://ss.brandon3055.com/48088]{link_to:"https://www.youtube.com/watch?v=MnUnsUzxMKU",width:100%}
		§link[https://www.youtube.com/watch?v=MnUnsUzxMKU]
	</td>
</tr>
</table>

§img[http://ss.brandon3055.com/6f18e]{link_to:"https://www.youtube.com/watch?v=8rBhQP1xqEU",width:45%}
§link[https://www.youtube.com/watch?v=8rBhQP1xqEU]