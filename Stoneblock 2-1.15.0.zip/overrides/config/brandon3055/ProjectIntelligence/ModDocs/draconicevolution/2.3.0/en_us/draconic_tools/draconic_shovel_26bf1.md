§align:center
##### §nDraconic Shovel§n

§img[http://ss.brandon3055.com/70bf2]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§616 Million RF capacity upgradable to 256 Million.

§63x3 base mining AOE. Upgradable to 9x9

§63 block dig depth. Upgradable to 9

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_shovel]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}