§align:center
##### §nEnergy I/O Crystal§n
§stack[draconicevolution:energy_crystal,1,3]{size:64} §stack[draconicevolution:energy_crystal,1,4]{size:64} §stack[draconicevolution:energy_crystal,1,5]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nStats

§9Basic§r
Capacity: 4 Million
Max Links: 2 

§5Wyvern§r
Capacity: 16 Million
Max Links: 3

§6Draconic§r
Capacity: 64 Million
Max Links: 4

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_crystal,1,3]{spacing:2}§recipe[draconicevolution:energy_crystal,1,4]{spacing:2}§recipe[draconicevolution:energy_crystal,1,5]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}