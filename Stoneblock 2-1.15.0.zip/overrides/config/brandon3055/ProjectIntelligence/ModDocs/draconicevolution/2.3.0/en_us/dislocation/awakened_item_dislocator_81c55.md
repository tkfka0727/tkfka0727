§align:center
##### §nItem Dislocator§n

§stack[draconicevolution:magnet,1,1]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
This is exactly the same as the regular Item Dislocator except it has a 32 block range!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:magnet,1,1]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}