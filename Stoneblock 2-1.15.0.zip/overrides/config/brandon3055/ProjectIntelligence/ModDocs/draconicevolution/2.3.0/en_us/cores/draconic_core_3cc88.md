§align:center
##### §nDraconic Core§n

§stack[draconicevolution:draconic_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
This is the lowest tier core used in a lot of basic crafting recipes.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}
§align:left

Side note: A better name for this would be something along the lines of "Basic Core".
The name Draconic Core has been caried over from the early days of DE, before the higher teir cores were introduced.
To avoid confusion its best to just think of this as the "Basic Core" and it will be renamed in the 1.13 update.