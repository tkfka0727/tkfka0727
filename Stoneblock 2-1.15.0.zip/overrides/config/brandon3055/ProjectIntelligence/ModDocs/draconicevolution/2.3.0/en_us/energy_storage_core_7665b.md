§align:center
##### §nEnergy Storage Core§n
The ultimate energy storage device.

§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Energy%20Core/Energy%20Core%20T8.jpg]{width:100%} 
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
If you like energy storage your going to love this!
If you don't... You should probably just stop reading here...

I give you the Draconic Energy core. Currently the largest energy storage device in modded Minecraft.

Alright so let's skip to the point: How much does it hold?
Well, there are 8 Tiers and each holds substantially more than the last.

§table{width:100%,colour:0x0,border_colour:0xffffff,vert_align:middle,padding:2,render_cells:true}
| :n35: 		| :n100: 	|
| §6Tier 1	| §b45.5 Million RF	|
| §6Tier 2	| §b273 Million RF	|
| §6Tier 3	| §b1.64 Billion RF	|
| §6Tier 4	| §b9.88 Billion RF	|
| §6Tier 5	| §b59.3 Billion RF	|
| §6Tier 6	| §b356 Billion RF	|
| §6Tier 7	| §b2.14 Trillion RF	|
| §6Tier 8	| §b...				|

Ok so about the tier 8... I'm not going to lie to you and tell you that its "Infinite" But its as close as you're going to get. 

Unless someone makes a mod that has, even more, storage but considering that the amount of storage this thing has is already just stupid well... 
I would have to question that person's sanity... Almost as much as I question my own.

As for Tier 8's actual capacity... Well... Its a §link[https://en.wikipedia.org/wiki/9223372036854775807]{alt_text:"BIG NUMBER!"}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nRecipe§n
§recipe[draconicevolution:energy_storage_core]{border_colour:0xc6c6c6}
§rule{colour:0x606060,height:3,width:100%}