§align:center
##### §nAwakened Draconium§n

§stack[draconicevolution:nugget,1,1]{size:32} §stack[draconicevolution:draconic_ingot]{size:32} §stack[draconicevolution:draconic_block]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Awakened Draconium is your next step towards crafting even more powerful tools, weapons and armor!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_ingot]{spacing:2}§recipe[draconicevolution:draconic_block]{spacing:2}§recipe[draconicevolution:nugget,1,1]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}