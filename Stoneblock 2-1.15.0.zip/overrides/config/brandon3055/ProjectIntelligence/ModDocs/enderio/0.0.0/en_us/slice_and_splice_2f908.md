§stack[enderio:block_slice_and_splice]{size:18,enable_tooltip:false}

§recipe[enderio:block_slice_and_splice]{spacing:4}