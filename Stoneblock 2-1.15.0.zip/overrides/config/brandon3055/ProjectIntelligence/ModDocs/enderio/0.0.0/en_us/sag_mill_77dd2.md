§stack[enderio:block_sag_mill]{size:18,enable_tooltip:false}§stack[enderio:block_sag_mill]{size:18,enable_tooltip:false}§stack[enderio:block_enhanced_sag_mill]{size:18,enable_tooltip:false}

§recipe[enderio:block_simple_sag_mill]{spacing:4}
§recipe[enderio:block_sag_mill]{spacing:4}
§recipe[enderio:block_enhanced_sag_mill]{spacing:4}