§stack[enderio:block_simple_stirling_generator]{size:18,enable_tooltip:false}§stack[enderio:block_stirling_generator]{size:18,enable_tooltip:false}

§recipe[enderio:block_simple_stirling_generator]{spacing:4}
§recipe[enderio:block_stirling_generator]{spacing:4}