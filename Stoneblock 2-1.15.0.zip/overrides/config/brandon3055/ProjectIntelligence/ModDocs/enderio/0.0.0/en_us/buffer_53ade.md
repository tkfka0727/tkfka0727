§stack[enderio:block_buffer]{size:18,enable_tooltip:false}§stack[enderio:block_buffer,1,1]{size:18,enable_tooltip:false}§stack[enderio:block_buffer,1,2]{size:18,enable_tooltip:false}§stack[enderio:block_buffer,1,3]{size:18,enable_tooltip:false}

§recipe[enderio:block_buffer]{spacing:4}
§recipe[enderio:block_buffer,1,1]{spacing:4}
§recipe[enderio:block_buffer,1,2]{spacing:4}
§recipe[enderio:block_buffer,1,3]{spacing:4}