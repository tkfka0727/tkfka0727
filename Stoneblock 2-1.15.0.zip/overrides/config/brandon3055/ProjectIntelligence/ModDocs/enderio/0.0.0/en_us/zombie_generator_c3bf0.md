§stack[enderio:block_zombie_generator]{size:18,enable_tooltip:false}§stack[enderio:block_franken_zombie_generator]{size:18,enable_tooltip:false}§stack[enderio:block_ender_generator]{size:18,enable_tooltip:false}

§recipe[enderio:block_zombie_generator]{spacing:4}
§recipe[enderio:block_franken_zombie_generator]{spacing:4}
§recipe[enderio:block_ender_generator]{spacing:4}