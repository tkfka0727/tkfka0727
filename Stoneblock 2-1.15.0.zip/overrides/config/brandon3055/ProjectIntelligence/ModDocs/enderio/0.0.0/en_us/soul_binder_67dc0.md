§stack[enderio:block_soul_binder]{size:18,enable_tooltip:false}

§recipe[enderio:block_soul_binder]{spacing:4}